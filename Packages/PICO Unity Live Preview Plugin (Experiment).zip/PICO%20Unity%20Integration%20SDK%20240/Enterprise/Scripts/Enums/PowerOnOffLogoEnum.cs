﻿namespace Unity.XR.PXR
{
    public enum PowerOnOffLogoEnum
    {
        PLPowerOnLogo=0,
        PLPowerOnAnimation=1,
        PLPowerOffAnimation=2
    }
}